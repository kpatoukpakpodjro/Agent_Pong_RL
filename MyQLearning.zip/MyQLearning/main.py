import game as g
import matplotlib.pylab as plt
import numpy as np

# @author: Kpodjro

def plot_agent_reward(rewards):
    """ Function to plot agent's accumulated reward vs. iteration """
    plt.plot(np.cumsum(rewards))
    plt.show()

class GameLearning:

    def __init__(self):
        while True:
            Choix_Agent = ['agentRL', 'human','agentIA']
            print('\n  **** Choisissez le type de jeu : **** ')
            choix = int(input('1. AgentRL vs AgentRL \n2. AgentRL vs Human \n3. AgentRL vs AgentIA\n Jeu :  = '))
            if choix >= 1 and choix <= 3:
                break
        self.game = g.Game(Choix_Agent[choix-1])

    def beginPlaying(self):
        self.game.play()

if __name__ == '__main__':
    gl = GameLearning()
    gl.beginPlaying()
